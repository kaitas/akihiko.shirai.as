﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WiimoteLib;	//WimoteLibの使用を宣言

namespace code4_17 {
	public partial class Form1 : Form {
		
		Wiimote wm = new Wiimote(); //Wiimoteの宣言

		public Form1() {
			Control.CheckForIllegalCrossThreadCalls = false; //おまじない フォームのアクセスを許可する
			InitializeComponent();
			wm.WiimoteChanged += wm_WiimoteChanged; //イベント関数の登録
			wm.Connect(); //WiiRemoteと接続
		}
		//Wiiリモコンの値が変化したときに呼ばれる関数
		void wm_WiimoteChanged(object sender, WiimoteChangedEventArgs args){
			WiimoteState ws = args.WiimoteState; //WiimoteStateの値を取得
			this.DrawForms(ws); //フォーム描写関数へ
		}

		//フォーム描写関数
		public void DrawForms(WiimoteState ws){
			this.label1.Text = "Button A:" + (ws.ButtonState.A);	//label1のTextにボタンAの状態を表示
			this.label2.Text = "Button B:" + (ws.ButtonState.B);	//label2のTextにボタンBの状態を表示
			this.label3.Text = "Button 1:" + (ws.ButtonState.One);	//label3のTextにボタン1の状態を表示
			this.label4.Text = "Button 2:" + (ws.ButtonState.Two);	//label4のTextにボタン2の状態を表示
		}
	}
}

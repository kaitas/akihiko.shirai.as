﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WiimoteLib;	//WimoteLibの使用を宣言

namespace code4_9 {
	public partial class Form1 : Form {

		Wiimote wm = new Wiimote(); //Wiimoteの宣言

		public Form1() {
			InitializeComponent();
			wm.Connect(); //Wiimoteの接続
		}

		private void button1_Click(object sender, EventArgs e) {
			wm.SetRumble(true); //バイブレーションON
		}

		private void button2_Click(object sender, EventArgs e) {
			wm.SetRumble(false); //バイブレーションOFF
		}
	}
}

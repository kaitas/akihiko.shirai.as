﻿using System;
using System.Drawing;
using System.Windows.Forms;
using WiimoteLib;  //WimoteLibの使用を宣言


namespace WiiRemoteMouse {
 public partial class Form1 : Form {
  Wiimote wm = new Wiimote();      //Wiimoteクラスを作成
  ButtonEvents wbe = new ButtonEvents(); //ボタンイベントクラスを作成
  Bitmap bmp; //|指ポインタ描画用
  System.Drawing.Point ScreenSize; //画面サイズを格納
  Boolean isConnected = false;     //WiiRemoteが接続されたか
  public Form1()
  {
    InitializeComponent();
   //グラフィックス下ごしらえ
   String url = "http://akihiko.shirai.as/projects/WiiRemote/finger.bmp";
   using (System.Net.WebClient wc = new System.Net.WebClient())
   using (System.IO.Stream st = wc.OpenRead(url))
   bmp = new Bitmap(st);
   // ※もちろんハードディスクから読むことも可能 
   // bmp = new Bitmap("c:\\WiiRemote\\yubi.png");
   bmp.MakeTransparent(bmp.GetPixel(0, 0)); //抜き色の指定
 
   //他スレッドからのコントロール呼び出し許可
   Control.CheckForIllegalCrossThreadCalls = false; 
   this.button2.Enabled = false; //切断ボタンを無効に
  }

#region WiiRemoteの状態が変化したときに呼ばれる関数
  void wm_WiimoteChanged(object sender, WiimoteChangedEventArgs args) {
    if (isConnected == true) {
      WiimoteState ws = args.WiimoteState;  //WiimoteStateの値を取得 
      DrawForms(ws);  // フォーム描画関数へ
      IR_Cursor(ws);  // 赤外線でマウスカーソル移動
      wbe.Events(ws); // ボタンイベント処理
      EffectsOut(ws); // LED・装飾
    } else {
     //切断
      this.wm.SetLEDs(0);       // LED消灯
      this.wm.SetRumble(false); // バイブレーター停止
      this.wm.Disconnect();     // WiiRemoteと切断
      this.wm.Dispose();        // オブジェクトの廃棄
    }
  }
#endregion

#region ボタンイベント開発用
/*
public void Events(WiimoteState ws) {
 if(ws.ButtonState.A) {
  if (isDown == false) {
   //もしも初めてボタンが押されたとき
   StartTime = System.Environment.TickCount; //押された時間を記録
   State  = "DOWN"; isDown = true;
  } else {
   //押されている時間がPressTimeより長ければHOLD
   if ((System.Environment.TickCount - StartTime) >= PressTime) {
    State = "HOLD";  //押され続けている
    Battery = ws.Battery;
    //メッセージボックスを表示
    MessageBox.Show(State + "\nBattery=" + Battery.ToString());
   }
  }
 } else {
  if (isDown == true) {    //ボタンが離された
    State = "UP";  isDown = false;
  }
 }
}

*/
#endregion

#region フォーム描画関数
  public void DrawFormsOrg(WiimoteState ws)
  {
    //グラフィックスを取得
    Graphics g = this.pictureBox1.CreateGraphics();
    g.Clear(Color.Black);//画面を黒色にクリア
    //もし赤外線を１つでも発見したら
    if (ws.IRState.IRSensors[0].Found)
    {
      //赤色でマーカ0を描画
      g.FillEllipse(Brushes.Red,
        ws.IRState.IRSensors[0].Position.X * 256,
        ws.IRState.IRSensors[0].Position.Y * 128, 5, 5);
      //青色でマーカ1を描画
      g.FillEllipse(Brushes.Blue,
        ws.IRState.IRSensors[1].Position.X * 256,
        ws.IRState.IRSensors[1].Position.Y * 128, 5, 5);
    }
    g.Dispose();//グラフィックスの解放
    label1.Text = "IR[0] " + ws.IRState.IRSensors[0].RawPosition.ToString()
              + "\nIR[1] " + ws.IRState.IRSensors[1].RawPosition.ToString();
}
#endregion

#region フォーム描画関数DrawString版
  public void DrawFormsString(WiimoteState ws)
  {
    //グラフィックスを取得
    Graphics g = this.pictureBox1.CreateGraphics();
    Font drawFont = new Font("Arial", 9);  //|フォントを指定
    SolidBrush drawBrush = new SolidBrush(Color.White); //|色は白
    String drawString = "Text";            //|描画文字列
    System.Drawing.Point pos = new System.Drawing.Point(0, 0); //|描画点
    int irsize;  //|赤外線センサーのサイズ
    g.Clear(Color.Black);//画面を黒色にクリア
    //もし赤外線を１つでも発見したら
    if (ws.IRState.IRSensors[0].Found)
    {
      //マーカ0の描画
      pos.X = (int)(ws.IRState.IRSensors[0].Position.X * 256);
      pos.Y = (int)(ws.IRState.IRSensors[0].Position.Y * 128);
      irsize = ws.IRState.IRSensors[0].Size + 5;
      g.FillEllipse(Brushes.Red, pos.X, pos.Y,irsize, irsize);
      drawString = "[" + ws.IRState.IRSensors[0].RawPosition.X + ", "
                       + ws.IRState.IRSensors[0].RawPosition.Y + "]";
      g.DrawString(drawString, drawFont, drawBrush, pos);
      //マーカ1の描画
      pos.X = (int)(ws.IRState.IRSensors[1].Position.X * 256);
      pos.Y = (int)(ws.IRState.IRSensors[1].Position.Y * 128);
      irsize = ws.IRState.IRSensors[0].Size + 5;
      g.FillEllipse(Brushes.Blue, pos.X, pos.Y, irsize, irsize);
      drawString = "[" + ws.IRState.IRSensors[1].RawPosition.X + ", "
                       + ws.IRState.IRSensors[1].RawPosition.Y + "]";
      g.DrawString(drawString, drawFont, drawBrush, pos);
    }
    g.Dispose();//グラフィックスの解放
    label1.Text = "IR[0] " + ws.IRState.IRSensors[0].RawPosition.ToString()
              + "\nIR[1] " + ws.IRState.IRSensors[1].RawPosition.ToString();
  }
#endregion

#region フォーム描画関数Finger版
  public void DrawForms(WiimoteState ws)
  {
    //グラフィックスを取得
    Graphics g = this.pictureBox1.CreateGraphics();
    Font drawFont = new Font("Arial", 9);  //|フォントを指定
    SolidBrush drawBrush = new SolidBrush(Color.White); //|色は白
    String drawString = "Text";            //|描画文字列
    System.Drawing.Point pos = new System.Drawing.Point(0, 0); //|描画点
    int irsize;  //|赤外線センサーのサイズ
    g.Clear(Color.Black);//画面を黒色にクリア
    //もし赤外線を１つでも発見したら
    if (ws.IRState.IRSensors[0].Found)
    {
      //マーカ0の描画
      pos.X = (int)(ws.IRState.IRSensors[0].Position.X * 256);
      pos.Y = (int)(ws.IRState.IRSensors[0].Position.Y * 128);
      irsize = ws.IRState.IRSensors[0].Size + 5;
      g.FillEllipse(Brushes.Red, pos.X, pos.Y, irsize, irsize);
      drawString = "[" + ws.IRState.IRSensors[0].RawPosition.X + ", "
                       + ws.IRState.IRSensors[0].RawPosition.Y + "]";
      g.DrawString(drawString, drawFont, drawBrush, pos);
      //マーカ1の描画
      pos.X = (int)(ws.IRState.IRSensors[1].Position.X * 256);
      pos.Y = (int)(ws.IRState.IRSensors[1].Position.Y * 128);
      irsize = ws.IRState.IRSensors[0].Size + 5;
      g.FillEllipse(Brushes.Blue, pos.X, pos.Y, irsize, irsize);
      drawString = "[" + ws.IRState.IRSensors[1].RawPosition.X + ", "
                       + ws.IRState.IRSensors[1].RawPosition.Y + "]";
      g.DrawString(drawString, drawFont, drawBrush, pos);
    }

    double radians, angle = 0.0f;
    //赤外線が2つ見えたらその中間をとる
    if (ws.IRState.IRSensors[1].Found)
    {
      pos.X = (int)(ws.IRState.IRSensors[0].Position.X * 256
       + ws.IRState.IRSensors[1].Position.X * 256) / 2;
      pos.Y = (int)(ws.IRState.IRSensors[0].Position.Y * 128
       + ws.IRState.IRSensors[1].Position.Y * 128) / 2;
      radians = Math.Atan2(ws.IRState.IRSensors[0].Position.Y - ws.IRState.IRSensors[1].Position.Y,
       ws.IRState.IRSensors[0].Position.X - ws.IRState.IRSensors[1].Position.X);
      angle = radians * (180 / Math.PI);

    } else {
      //赤外線が1つなら、1つめの値を採用する
      pos.X = (int)(ws.IRState.IRSensors[0].Position.X * 256);
      pos.Y = (int)(ws.IRState.IRSensors[0].Position.Y * 128);
    }
    double d = angle / (180 / Math.PI);    //ラジアン変換
    //2D回転変換
    float x = pos.X;
    float y = pos.Y;
    float x1 = x + bmp.Width * (float)Math.Cos(d);
    float y1 = y + bmp.Width * (float)Math.Sin(d);
    float x2 = x - bmp.Height * (float)Math.Sin(d);
    float y2 = y + bmp.Height * (float)Math.Cos(d);
    //新しい描画位置
    System.Drawing.PointF[] destinationPoints = {new System.Drawing.PointF(x, y),
                    new System.Drawing.PointF(x1, y1),
                    new System.Drawing.PointF(x2, y2)};
    //画像を表示
    g.DrawImage(bmp, destinationPoints);
///
    g.Dispose();//グラフィックスの解放
    label1.Text = "IR[0] " + ws.IRState.IRSensors[0].RawPosition.ToString()
              + "\nIR[1] " + ws.IRState.IRSensors[1].RawPosition.ToString();
  }
#endregion



#region フォーム描画関数3
  public void DrawFormsThree(WiimoteState ws)
  {
    //グラフィックスを取得
    Graphics g = this.pictureBox1.CreateGraphics();

    System.Drawing.Point pos = new System.Drawing.Point(0, 0);
    System.Drawing.Rectangle rect = new Rectangle(0, 0, 10, 10);

    Font drawFont = new Font("Arial", 9);

    SolidBrush drawBrush = new SolidBrush(Color.White);
    double radians, angle = 0.0f;

    String drawString = "Text";
    
    Bitmap targetBMP;
    targetBMP = new Bitmap("c:\\WiiRemote\\yubi.png");
    targetBMP.MakeTransparent(targetBMP.GetPixel(0, 0));

    System.Drawing.PointF drawPoint = new System.Drawing.PointF(150.0F, 150.0F);

    g.Clear(Color.Black);//画面を黒色にクリア
    //もし赤外線を１つでも発見したら
    if (ws.IRState.IRSensors[0].Found)
    {
      //赤色でマーカ0を描画
      g.FillEllipse(Brushes.Red,
        ws.IRState.IRSensors[0].Position.X * 256,
        ws.IRState.IRSensors[0].Position.Y * 128,
        ws.IRState.IRSensors[0].Size + 5,
        ws.IRState.IRSensors[0].Size + 5);
      //青色でマーカ1を描画
      g.FillEllipse(Brushes.Blue,
        ws.IRState.IRSensors[1].Position.X * 256,
        ws.IRState.IRSensors[1].Position.Y * 128,
        ws.IRState.IRSensors[1].Size + 5,
        ws.IRState.IRSensors[1].Size + 5);

      //赤外線が2つ見えたらその中間をとる
      if (ws.IRState.IRSensors[1].Found)
      {
        pos.X = (int)(ws.IRState.IRSensors[0].Position.X * 256
         + ws.IRState.IRSensors[1].Position.X * 256) / 2;
        pos.Y = (int)(ws.IRState.IRSensors[0].Position.Y * 128
         + ws.IRState.IRSensors[1].Position.Y * 128) / 2;
        radians = Math.Atan2(ws.IRState.IRSensors[0].Position.Y - ws.IRState.IRSensors[1].Position.Y,
         ws.IRState.IRSensors[0].Position.X - ws.IRState.IRSensors[1].Position.X);
        angle = radians * (180 / Math.PI);

      }
      else
      {
        //赤外線が1つなら、1つめの値を採用する
        pos.X = (int)(ws.IRState.IRSensors[0].Position.X * 256);
        pos.Y = (int)(ws.IRState.IRSensors[0].Position.Y * 128);
      }
      rect.Location = pos;
      rect.Height = 10; rect.Width = 10;
      drawString = "{" + rect.X + ", " + rect.Y + "}";
      g.DrawString(drawString, drawFont, drawBrush, pos);
      g.DrawPie(Pens.Azure, rect, (float)-angle, (float)angle);

      //ラジアン単位に変換
      double d = angle / (180 / Math.PI);
      //新しい座標位置を計算する
      float x = pos.X;
      float y = pos.Y;
      float x1 = x + targetBMP.Width * (float)Math.Cos(d);
      float y1 = y + targetBMP.Width * (float)Math.Sin(d);
      float x2 = x - targetBMP.Height * (float)Math.Sin(d);
      float y2 = y + targetBMP.Height * (float)Math.Cos(d);
      //PointF配列を作成
      System.Drawing.PointF[] destinationPoints = {new System.Drawing.PointF(x, y),
                    new System.Drawing.PointF(x1, y1),
                    new System.Drawing.PointF(x2, y2)};
      //画像を表示
      g.DrawImage(targetBMP, destinationPoints);

    }
    g.Dispose();//グラフィックスの解放
    label1.Text = "IR[0] " + ws.IRState.IRSensors[0].RawPosition.ToString()
              + "\nIR[1] " + ws.IRState.IRSensors[1].RawPosition.ToString()
              + "\n size[0] " + ws.IRState.IRSensors[0].Size.ToString()
              + " size[1] " + ws.IRState.IRSensors[1].Size.ToString()
//              + "\nlast{x,y} " + lastIx.ToString() + lastIy.ToString() 
              + "\n angle = " + angle;
}
#endregion



#region 赤外線でマウスカーソル移動
  public void IR_Cursor(WiimoteState ws)
  {
    ScreenSize.X = Screen.PrimaryScreen.Bounds.Width;  //画面サイズ横幅
    ScreenSize.Y = Screen.PrimaryScreen.Bounds.Height; //画面サイズ縦幅
    //赤外線座標(見えたときだけ更新)
    float Ix1 = 0.5f, Iy1 = 0.5f, Ix0 = 0.5f, Iy0 = 0.5f;
    float Ix, Iy; //赤外線座標の平均
    int px, py; //最終的なマウスカーソルの位置   
    if (ws.IRState.IRSensors[1].Found) {
      Ix1 = ws.IRState.IRSensors[1].Position.X;
      Iy1 = ws.IRState.IRSensors[1].Position.Y;
      Ix0 = ws.IRState.IRSensors[0].Position.X;
      Iy0 = ws.IRState.IRSensors[0].Position.Y;
      //Ix1,Iy1に大きい方(左)を格納したい
      if (Ix1<Ix0) {
        Ix0 = Ix1; Iy0 = Iy1;
        Ix1 = ws.IRState.IRSensors[0].Position.X;
        Iy1 = ws.IRState.IRSensors[0].Position.Y;
      }
      Ix =  Ix0; Iy = Iy0; //ここで平均をとっても良いだろう
      px = (int)(ScreenSize.X * (1 - Ix)); //X座標は反転
      py = (int)( Iy * ScreenSize.Y);
      //マウスカーソルを指定位置へ移動
      System.Windows.Forms.Cursor.Position = new System.Drawing.Point(px, py);
    }
  }
#endregion

#region LED・装飾
  public void EffectsOut(WiimoteState ws)
  {
    //25%ずつLEDを表示させる
    wm.SetLEDs((int)Math.Pow(2.0f, (int)(ws.Battery / 25) + 1) - 1);
  }
#endregion

#region フォームのボタン処理(接続・切断)
  //接続ボタンが押されたら
  private void button1_Click(object sender, EventArgs e) {
   if (this.isConnected == false) {
    this.wm = new Wiimote(); //WiiRemoteの初期化
    this.wm.Connect();       //WiiRemote接続
    this.wm.SetReportType(InputReport.IRAccel, true); //リポートタイプの設定
    this.wm.SetLEDs(0); //LED を消す
    this.wm.SetRumble(false); //バイブレータストップ
    this.button1.Enabled = false;  //接続ボタンを無効
    this.button2.Enabled = true;   //切断ボタンを有効
    this.wm.WiimoteChanged += wm_WiimoteChanged; //コールバックを登録
    this.isConnected = true; //接続状態をtrue
   }
  }

  //切断ボタンが押されたら
  private void button2_Click(object sender, EventArgs e) {
   if (this.isConnected == true) {
    this.wm.WiimoteChanged -= wm_WiimoteChanged;  //コールバックを削除
    this.button1.Enabled = true;   //接続ボタンを有効
    this.button2.Enabled = false;  //切断ボタンを無効
    this.isConnected = false; //接続状態をfalse
//    this.wm.Dispose();
   }
  }
#endregion


 } 
}

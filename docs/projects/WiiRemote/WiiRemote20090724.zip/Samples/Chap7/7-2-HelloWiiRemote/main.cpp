#include "../../wiimote.h"
int _tmain(int argc, _TCHAR* argv[])
{
  wiimote cWiiRemote;
  _tprintf(_T("Hello, WiiRemote!\n"));
  _tprintf(_T("contains WiiYourself! wiimote code by gl.tter\nhttp://gl.tter.org\n")); //���C�Z���X�\��
  return 0;
}

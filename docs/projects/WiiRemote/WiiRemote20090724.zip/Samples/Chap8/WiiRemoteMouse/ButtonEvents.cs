﻿using WiimoteLib;
//DllImportに必要なusing
using System;
using System.Runtime.InteropServices;

namespace WiiRemoteMouse
{
 class ButtonEvents {
  bool isDown;
  int StartTime, PressTime = 1000;
  string State = "";

#region DLLインポート
  [DllImport("user32.dll")]  //DLL読み込み
  extern static uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

  [StructLayout(LayoutKind.Sequential)]
  struct INPUT  {
    public int type;
    public MOUSEINPUT mi;
  }

  [StructLayout(LayoutKind.Sequential)]
  struct MOUSEINPUT  {
    public int dx;
    public int dy;
    public int mouseData;
    public int dwFlags;
    public int time;
    public IntPtr dwExtraInfo;
  }
#endregion

#region ボタンイベント処理
  public void Events(WiimoteState ws) {
   INPUT[] input = new INPUT[1];  //|マウスイベントを格納
   if (ws.ButtonState.B) {
     input[0].mi.dwFlags = 0x0008;                  //|右マウスダウン
     SendInput(1, input, Marshal.SizeOf(input[0])); //|マウスイベントを送信
   } else {
     input[0].mi.dwFlags = 0x0010;                   //|右マウスアップ
     SendInput(1, input, Marshal.SizeOf(input[0]));  //|マウスイベントを送信
   }
   
   if (ws.ButtonState.A) {
    if (isDown == false) {
     //もしも初めてボタンが押されたとき
     StartTime = System.Environment.TickCount; //押された時間を記録
     State = "DOWN"; isDown = true;
     input[0].mi.dwFlags = 0x0002;                  //|左マウスダウン
     SendInput(1, input, Marshal.SizeOf(input[0])); //|マウスイベントを送信
    } else {
    //押されている時間がPressTimeより長ければHOLD→右クリック
     if ((System.Environment.TickCount - StartTime) >= PressTime) {
      State = "HOLD";  //押され続けている
      input[0].mi.dwFlags = 0x0008;                  //|右マウスダウン
      SendInput(1, input, Marshal.SizeOf(input[0])); //|マウスイベントを送信
     }
    }
   } else {
    if (isDown == true) {    //ボタンが離された
     State = "UP"; isDown = false;
     input[0].mi.dwFlags = 0x0004;                   //|左マウスアップ
     SendInput(1, input, Marshal.SizeOf(input[0]));  //|マウスイベントを送信
     input[0].mi.dwFlags = 0x0010;                   //|右マウスアップ
     SendInput(1, input, Marshal.SizeOf(input[0]));  //|マウスイベントを送信
    }
   }
  }
#endregion
 }
}
